$(document).ready(function ()
{
	$('.material-button-toggle').on("click", function ()
	{
	    $(this).toggleClass('open');
	    $('.option').toggleClass('scale-on');
	    $('[data-toggle="tooltip"]').tooltip();  
	});
});